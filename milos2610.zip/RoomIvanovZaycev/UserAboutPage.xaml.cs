﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RoomIvanovZaycev
{
    /// <summary>
    /// Логика взаимодействия для UserAboutPage.xaml
    /// </summary>
    public partial class UserAboutPage : Page
    {
        public UserAboutPage()
        {
            InitializeComponent();
            tbPara.Text = "Мебельный магазин Room Interior занимается продажей мебели по всей России.\n" +
                "Используется ИС мебельного магазина Room Interior.";
        }
    }
}

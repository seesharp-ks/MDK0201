﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using RoomIvanovZaycev.Helper;
using RoomIvanovZaycev.Admin;
namespace RoomIvanovZaycev.Profile
{
    /// <summary>
    /// Логика взаимодействия для ProfilePage.xaml
    /// </summary>
    public partial class ProfilePage : Page
    {
        ZIEntities entis = new ZIEntities();
        public User newUser = null;
        AdminMain adm = new AdminMain();
        public ProfilePage()
        {
            InitializeComponent();

            BitmapImage bi = new BitmapImage();//фоточка
            bi.BeginInit();
            if (Auth.Role.Equals("Пользователь")) { bi.UriSource = new Uri("/PhotoUser/user-1.jpg", UriKind.Relative); }
            else if (Auth.Role.Equals("Менеджер")) { bi.UriSource = new Uri("/PhotoUser/user-2.png", UriKind.Relative); }
            else if (Auth.Role.Equals("Администратор")) { bi.UriSource = new Uri("/PhotoUser/user-3.jpg", UriKind.Relative); }
            else { bi.UriSource = new Uri("/Resources/logo.png", UriKind.Relative); }
            bi.EndInit();
            imgProfile.Source = bi;

            
            tbLogin.Text = Auth.model.Login;
            tbRole.Text = Auth.model.Role.NameRole;
            tbA.Text = Auth.model.FirstName;
            tbB.Text = Auth.model.LastName;
            tbC.Text = Auth.model.Patronymic;
            tbD.Text = Auth.model.Phone;
            tbE.Text = Auth.model.Email;
        }

        private void SaveChangesProfile_Click(object sender, RoutedEventArgs e)
        {
            saveProfile();
            entis.SaveChanges();
        }

        private void saveProfile()
        {
            newUser = entis.User.Find(Auth.model.IdUser);
            var res = MessageBox.Show("Сохранить изменения?", "Изменение профиля", MessageBoxButton.YesNo,MessageBoxImage.Question);
            if(tbA.Text.Length < 1 || tbB.Text.Length < 1 || tbC.Text.Length < 1 || tbD.Text.Length < 1 || tbE.Text.Length < 1)
            {
                MessageBox.Show("Поля не могут быть пустыми", "Перепроверьте введённые данные", MessageBoxButton.OK);
            }
            if (res == MessageBoxResult.Yes)
            {
                newUser.FirstName = tbA.Text;
                newUser.LastName = tbB.Text;
                newUser.Patronymic = tbC.Text;
                newUser.Phone = tbD.Text; 
                newUser.Email = tbE.Text;
                MessageBox.Show("Пользователь изменён", "Успех", MessageBoxButton.OK, MessageBoxImage.Asterisk);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RoomIvanovZaycev.Manager
{
    /// <summary>
    /// Логика взаимодействия для ManagerPageOrder.xaml
    /// </summary>
    public partial class ManagerPageOrder : Page
    {
        public Helper.ZIEntities context = new Helper.ZIEntities();
        public ManagerPageOrder()
        {
            InitializeComponent();
            LvOrder.ItemsSource = context.Order.ToList();
        }

        private void btnLookOrder_Click(object sender, RoutedEventArgs e)
        {
            if (LvOrder.SelectedItem as Helper.Order == null)
            {
                var result = MessageBox.Show("Выберите товар", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Information);
                if (result == MessageBoxResult.OK)
                    return;
            }
            WindowOrderProduct windowOrderProduct = new WindowOrderProduct(LvOrder.SelectedItem as Helper.Order);
            windowOrderProduct.Show();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
namespace RoomIvanovZaycev.Manager
{
    /// <summary>
    /// Логика взаимодействия для WindowOrderProduct.xaml
    /// </summary>
    public partial class WindowOrderProduct : Window
    {
        public Helper.ZIEntities context = new Helper.ZIEntities();
        public WindowOrderProduct(Helper.Order order)
        {
            InitializeComponent();
            List<Helper.Product> products = new List<Helper.Product>();
            Helper.OrderProduct orderProduct = context.OrderProduct.First(i => i.IdOrder == order.IdOrder);
            List<Helper.OrderProduct> orderProducts = context.OrderProduct.Where(i => i.IdOrder == orderProduct.IdOrder).ToList();
            foreach (Helper.OrderProduct orderPr in orderProducts)
                products.Add(context.Product.Find(orderPr.IdProduct));
            LvOrderProduct.ItemsSource = products;
        }
    }
}

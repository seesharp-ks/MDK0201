﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RoomIvanovZaycev.Admin
{
    /// <summary>
    /// Логика взаимодействия для AdminMain.xaml
    /// </summary>
    public partial class AdminMain : Window
    {
        public AdminMain()
        {
            InitializeComponent();
            if (Auth.Role.Equals("Пользователь"))
            {
                btnListUser.Visibility = Visibility.Collapsed;
                btnListOrders.Visibility = Visibility.Collapsed;
            }
            else if (Auth.Role.Equals("Менеджер"))
            {
                btnListUser.Visibility = Visibility.Collapsed;
                btnGoToProfile.Visibility = Visibility.Collapsed;
                btnCompanyInfo.Visibility = Visibility.Collapsed;
            }
            else if (Auth.Role.Equals("Администратор"))
            {
                btnListUser.Visibility = Visibility.Collapsed;
                btnListOrders.Visibility = Visibility.Collapsed;
                btnCompanyInfo.Visibility = Visibility.Collapsed;
                btnGoToProfile.Visibility = Visibility.Collapsed;
            }
        }

        private void btnListProduct_Click(object sender, RoutedEventArgs e)
        {
            frmMainAdmin.Navigate(new AdminPageProduct());
        }

        private void btnListUser_Click(object sender, RoutedEventArgs e)
        {
            frmMainAdmin.Navigate(new AdminPageUser());
        }

        private void btnListExitProfile_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }

        private void btnListCloseAPP_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btnGoToProfile_Click(object sender, RoutedEventArgs e)
        {
            frmMainAdmin.Navigate(new Profile.ProfilePage());
        }

        private void btnListOrders_Click_1(object sender, RoutedEventArgs e)
        {
            frmMainAdmin.Navigate(new Manager.ManagerPageOrder());
        }

        private void btnCompanyInfo_Click(object sender, RoutedEventArgs e)
        {
            frmMainAdmin.Navigate(new UserAboutPage());
        }
    }
}

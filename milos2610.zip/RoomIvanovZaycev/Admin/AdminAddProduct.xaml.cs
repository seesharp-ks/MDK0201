﻿using Microsoft.Win32;
using System;
using System.Windows;
using System.Windows.Media.Imaging;
using RoomIvanovZaycev.Helper;
using System.Linq;
using System.IO;
using System.Collections.Generic;

namespace RoomIvanovZaycev.Admin
{
    /// <summary>
    /// Логика взаимодействия для AdminAddProduct.xaml
    /// </summary>
    public partial class AdminAddProduct : Window
    {
        private string fileName = null,filePath = null;
        bool editingImage = false, editingProduct = false;
        ZIEntities ents = new ZIEntities();
        List<string> listFilter = new List<string>();
        public Product updateProduct = new Product();
        public AdminAddProduct()
        {
            InitializeComponent();
            var category = ents.Category.ToList();
            foreach (var i in category)
                listFilter.Add(i.NameCategory);
            cmbCategory.ItemsSource = listFilter;
        }

        public AdminAddProduct(Product product)
        {
            InitializeComponent();
            editingProduct = true;
            updateProduct = product;

            var category = ents.Category.ToList();
            foreach (var i in category)
                listFilter.Add(i.NameCategory);
            cmbCategory.ItemsSource = listFilter;
            NameProduct.Text = product.NameProduct;
            ProductMaterial.Text = product.Material;
            Price.Text = product.Price.ToString();
            ProductDescription.Text = product.Description;
            if(product.PhotoProduct != null)
            {
                BitmapImage myBitmapImage = new BitmapImage();
                myBitmapImage.BeginInit();
                myBitmapImage.StreamSource = new MemoryStream(product.PhotoProduct);
                myBitmapImage.EndInit();
                ImageProduct.Source = myBitmapImage;
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (editingProduct)
            { editProduct(); return; }

            if (NameProduct.Text == null || Price.Text == null || ProductDescription.Text == null || ProductMaterial.Text == null)
            {
                MessageBox.Show("Заполните все поля", "Пожалуйста", MessageBoxButton.OK);
                return;
            }

            var result = MessageBox.Show("Добавить продукт?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);
            Product prodAdd = new Product();
            prodAdd.NameProduct = NameProduct.Text;
            prodAdd.IdCategory = cmbCategory.SelectedIndex + 1;
            prodAdd.PhotoProduct = File.ReadAllBytes(filePath);//...
            prodAdd.Price = Convert.ToDecimal(Price.Text);
            prodAdd.Description = ProductDescription.Text;
            prodAdd.Material = ProductMaterial.Text;

            if (editingImage)
                prodAdd.PhotoProduct = File.ReadAllBytes(fileName);

            if (prodAdd.PhotoProduct == null || prodAdd.IdCategory == 0)
                MessageBox.Show("Отсутствует фото, либо не выбрала категория", "Ошибка", MessageBoxButton.OK);
            ents.Product.Add(prodAdd);
            ents.SaveChanges();
            MessageBox.Show("Товар успешно добавлен!", "Успех.", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ImageAdd_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog { Filter = "Картинки|*.jpg;*.jpeg;*.bmp;*.gif;*.png|Все файлы|*.*" };

            if (ofd.ShowDialog() == true)
            {
                filePath = ofd.FileName;
                ImageProduct.Source = new BitmapImage(new Uri(filePath));
            }
        }

        private void CloseAdd_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void editProduct()
        {
            Product product = ents.Product.Find(updateProduct.IdProduct);
            if (NameProduct.Text == null || Price.Text == null || ProductDescription.Text == null || ProductMaterial.Text == null)
            {
                MessageBox.Show("Заполните все поля", "Пожалуйста", MessageBoxButton.OK);
                return;
            }
            var result = MessageBox.Show("Вы хотите изменить товар?", "Подтверждение", MessageBoxButton.YesNo);
            product.NameProduct = NameProduct.Text;
            product.IdCategory = cmbCategory.SelectedIndex + 1; //...
            product.Price = Convert.ToDecimal(Price.Text);
            product.Description = ProductDescription.Text;
            product.Material = ProductMaterial.Text;
            if (editingImage)
                product.PhotoProduct = File.ReadAllBytes(fileName);
            ents.SaveChanges();
            MessageBox.Show("Товар успешно обновлен", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            this.Close();
        }
    }
}

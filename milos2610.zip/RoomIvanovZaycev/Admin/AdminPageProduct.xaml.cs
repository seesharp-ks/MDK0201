﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace RoomIvanovZaycev.Admin
{
    /// <summary>
    /// Логика взаимодействия для AdminPageProduct.xaml
    /// </summary>
    public partial class AdminPageProduct : Page
    {
        Helper.ZIEntities ents = new Helper.ZIEntities();
        List<Helper.Product> listProduct = new List<Helper.Product>();
        private int numPage = 0;
        List<string> listSort = new List<string>() { "Наименование (по возрастанию)", "Наименование (по убыванию)", "Стоимость (по возрастанию)", "Стоимость (по убыванию)" };
        List<string> listFilter = new List<string>();

        public void Filter()
        {
            listProduct = ents.Product.ToList();
            var selectSort = cmbSortingPrice.SelectedIndex;
            switch (selectSort)
            {
                case 0:
                    listProduct = listProduct.OrderBy(i => i.NameProduct).ToList();
                    break;
                case 1:
                    listProduct = listProduct.OrderByDescending(i => i.NameProduct).ToList();
                    break;
                case 2:
                    listProduct = listProduct.OrderBy(i => i.Price).ToList();
                    break;
                case 3:
                    listProduct = listProduct.OrderByDescending(i => i.Price).ToList();
                    break;
                default:
                    listProduct = listProduct.OrderBy(i => i.IdProduct).ToList();
                    break;
            }
            var selectFilter = cmbFiltrationCategory.SelectedIndex;
            if (selectFilter != 0)
                listProduct = listProduct.Where(i => i.IdCategory == selectFilter).ToList();
            
            listProduct = listProduct.Skip(10 * numPage).Take(10).ToList();
            listProduct = listProduct.Where(i => i.NameProduct.ToLower().Contains(txbSearch.Text.ToLower())).ToList();
            LvProduct.ItemsSource = listProduct;
        }

        public AdminPageProduct()
        {
            InitializeComponent();

            if (Auth.Role.Equals("Пользователь"))
            {
                btnAddProduct.Visibility = Visibility.Collapsed;
                btnEditProduct.Visibility = Visibility.Collapsed;
                btnDeleteProduct.Visibility = Visibility.Collapsed;
            }
            else if (Auth.Role.Equals("Менеджер"))
            {
                btnAddToBasket.Visibility = Visibility.Collapsed;
                btnAddProduct.Visibility = Visibility.Collapsed;
                btnDeleteProduct.Visibility = Visibility.Collapsed;
                btnSwitchToBasket.Visibility = Visibility.Collapsed;
            }
            else if (Auth.Role.Equals("Администратор"))
            {
                btnAddToBasket.Visibility = Visibility.Collapsed;
                btnEditProduct.Visibility = Visibility.Collapsed;
                btnSwitchToBasket.Visibility = Visibility.Collapsed;
            }

            var listProduct = ents.Product.ToList();
            LvProduct.ItemsSource = ents.Product.ToList();

            var category = ents.Category.ToList();
            foreach (var i in category)
                listFilter.Add(i.NameCategory);

            listFilter.Insert(0, "Все категории");

            cmbFiltrationCategory.ItemsSource = listFilter;
            cmbFiltrationCategory.SelectedIndex = 0;

            cmbSortingPrice.ItemsSource = listSort;
            cmbSortingPrice.SelectedIndex = 0;
        }

        private void btnBackFrm_Click(object sender, RoutedEventArgs e)
        {
            Content = null;
        }

        private void cmbFiltrationCategory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Filter();
        }

        private void cmbSortingPrice_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Filter();
        }

        private void txbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            listProduct = listProduct.Where(i => i.NameProduct.ToLower().Contains(txbSearch.Text.ToLower())).ToList();
        }

        private void btnLastPage_Click(object sender, RoutedEventArgs e)
        {
            if (numPage > 0)
            {
                numPage--;
                tbckPage.Text = (numPage + 1).ToString();
            }
            Filter();
        }

        private void btnNextPage_Click(object sender, RoutedEventArgs e)
        {
            if (listProduct.Count > 0)
            {
                numPage++;
                tbckPage.Text = (numPage + 1).ToString();
            }
            Filter();
        }

        private void btnEditProduct_Click(object sender, RoutedEventArgs e)
        {
            updateProduct();
        }

        private void updateProduct()
        {
            if (LvProduct.SelectedItem as Helper.Product == null)
            {
                var result = MessageBox.Show("Выберете товар", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Information);
                switch (result)
                {
                    case MessageBoxResult.OK: return;
                }
            }
            AdminAddProduct addProd = new AdminAddProduct(LvProduct.SelectedItem as Helper.Product);

            addProd.Show();
            LvProduct.ItemsSource = ents.Product.ToList();
        }

        private void btnAddProduct_Click(object sender, RoutedEventArgs e)
        {
            new AdminAddProduct().Show();
        }

        private void btnDeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (LvProduct.SelectedItem == null)
                    MessageBox.Show("Товар не выбран", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                var a = LvProduct.SelectedItem as Helper.Product;
                ents.Product.Remove(a);
                ents.SaveChanges();
                LvProduct.ItemsSource = ents.Product.ToList();
            }
            catch (Exception ex) { MessageBox.Show("Товар находится в заказе.","Невозможно удалить товар",MessageBoxButton.OK,MessageBoxImage.Asterisk); }
        }

        private void btnAddToBasket_Click(object sender, RoutedEventArgs e)
        {
            Helper.Product product = LvProduct.SelectedItem as Helper.Product;
            if (product != null)
            {
                Helper.Basket bask = new Helper.Basket();
                bask.IdProduct = product.IdProduct;
                bask.IdUser = Auth.model.IdUser;
                bask.Price = product.Price;
                ents.Basket.Add(bask);
                ents.SaveChanges();
            }
            else
                MessageBox.Show("Товар не выбран!", "Ошибка", MessageBoxButton.OK);
        }

        private void btnSwitchToBasket_Click(object sender, RoutedEventArgs e)
        {
            Content = null;
            NavigationService.Navigate(new Basket());
        }
    }
}

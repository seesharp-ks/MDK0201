﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using RoomIvanovZaycev.Admin;
using System.Linq;
using System;

namespace RoomIvanovZaycev
{
    /// <summary>
    /// Логика взаимодействия для Basket.xaml
    /// </summary>
    public partial class Basket : Page
    {
        List<Helper.Product> listProduct = new List<Helper.Product>();
        public Helper.ZIEntities context = new Helper.ZIEntities();
        public Basket()
        {
            InitializeComponent();
            updateList();
        }


        private void btnClean_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Вы хотите очистить корзину?", "Подтверждение", MessageBoxButton.YesNo);
            if (result == MessageBoxResult.Yes)
                cleanBasket();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (context.Basket != null)
            {
                Helper.Product product = LvProductBasket.SelectedItem as Helper.Product;

            try
            {
                Helper.Basket basket = context.Basket.Remove(context.Basket.First(i => i.IdProduct.Equals(product.IdProduct)));
                context.Basket.Remove(basket);
                context.SaveChanges();
            }
            catch(Exception){MessageBox.Show("Корзина пуста, нечего удалять.","Пустая корзина", MessageBoxButton.OK);}

                updateList();
            }
        }

        private void btnCreateOrder_Click(object sender, RoutedEventArgs e)
        {

            Helper.Order order = new Helper.Order();
            order.IdUser = Auth.model.IdUser;
            order.Date = DateTime.Now;
            context.Order.Add(order);
            foreach (Helper.Product product in listProduct)
            {
                Helper.OrderProduct orderProduct = new Helper.OrderProduct();
                orderProduct.IdOrder = order.IdOrder;
                orderProduct.IdProduct = product.IdProduct;
                context.OrderProduct.Add(orderProduct);
            }
            context.SaveChanges();
            cleanBasket();
            MessageBox.Show("Заказ оформлен", "Подтверждение", MessageBoxButton.OK);
    }

        private void updateList()
        {
            listProduct.Clear();
            List<Helper.Basket> listBasket = context.Basket.Where(i => i.IdUser.Equals(Auth.model.IdUser)).ToList();
            foreach (Helper.Basket basket in listBasket)
                listProduct.Add(context.Product.FirstOrDefault(i => i.IdProduct.Equals(basket.IdProduct)));
            LvProductBasket.ItemsSource = listProduct;
            LvProductBasket.Items.Refresh();
        }

        private void cleanBasket()
        {
            List<Helper.Basket> listBasket = context.Basket.Where(i => i.IdUser.Equals(Auth.model.IdUser)).ToList();
            foreach (Helper.Basket basket in listBasket)
                context.Basket.Remove(basket);
            context.SaveChanges();
            updateList();
        }
    }
}

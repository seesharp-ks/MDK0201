﻿using System.Windows;
using System.Windows.Controls;
using System;
using System.Linq;
using RoomIvanovZaycev.Helper;
namespace RoomIvanovZaycev
{
    /// <summary>
    /// Логика взаимодействия для Auth.xaml
    /// </summary>
    public partial class Auth : Page
    {
        public static string Role;
        public static User model;
        public static ZIEntities ents = new ZIEntities();
        public Auth()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btnEnter_Click(object sender, RoutedEventArgs e)
        {
            model = ents.User.FirstOrDefault(i => i.Login == txbLogin.Text && i.Password == psbPassword.Password);
            Role = model.Role.NameRole;
            if (psbPassword.Password == psbPasswordRepeat.Password)
            {
                if (model == null)
                    MessageBox.Show("Пользователь не найден, повторите попытку", "Пользователь не найден", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                else if (model.IdRole == 1 || model.IdRole == 2 || model.IdRole == 3)
                {
                    new Admin.AdminMain().Show();
                    Application.Current.MainWindow.Close();
                }
            }
            else MessageBox.Show("Пароль не совпадает, повторите попытку", "Ошибка ввода пароля", MessageBoxButton.OK);
        }
    }
}
